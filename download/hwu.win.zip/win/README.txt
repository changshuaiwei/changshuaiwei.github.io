PROGRAM: HWU

DESCRIPTION: Heterogeneity Weighted U test

AUTHOR: Changshuai Wei

CONTACT: weichangshuai@gmail.com	

YEAR: 2016

LICENSE: Released under GNU General Public License, v2 (see
COPYING.txt)

DOCUMENTATION: http://changshuaiwei.github.io/


COMPILATION: You will need a standard C++ compiler such as GNU g++  (version 3), as well as Boost c++ library (v1.55.0) and Eigen c++ library(v3.2).


Using HWU:

1:a simple one

hwu --bfile NIC --hwu --wIBS-wt --out NIC.rst

2:a complicated one

hwu --bfile NIC --hwu --dv 3 --cov all.cov.txt --flt --mp 20 --force-core  --cov-wt cov1.txt --out NIC.rst

########################
#####Options For HWU######
########################

<string> stands for some strings. <int> stands for some int number.

1. --bfile <string> : read plink binary format data files <string>

2. --file <string>: read text format data files <string>

3. --hwu: perform HWU analysis

4. --out <string>: output files <string>

5. --wIBS-wt: use weighted IBS to construct latent population structure

6. --IBS-wt: use IBS to construct latent population structure

7: --cov-wt <string> : use covariates in <string> files to construct latent population structure

8: --dv <int>: output the most significant <int> SNPs (for high demensional scan)

9. --flt : use float accuracy when calculate the rank of SNPs (for  high demensional scan)

10. --mp <int>: use <int> cpus (if the machine has) to performce parallel computing (for  high demensional scan)

11. --write-Wmt <string> : output kappa matrix for latent population structure to file <string>

12. --read-Wmt <string>: read kappa matrix stored in file <string>

13. --cov <string>: read covariates that used for covariates adjustment in file <string>

14 --PCwt <int>: calculate the first <int> eigen vectors for matrix kappa

15. --screen <int>: screening variables using standardized HWU


