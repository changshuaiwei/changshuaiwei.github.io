PROGRAM: GTSU

DESCRIPTION: Gene-Trait Similarity U test

AUTHOR: Changshuai Wei

CONTACT: cwei@epi.msu.edu

YEAR: 2013

LICENSE: Released under GNU General Public License, v2 (see
COPYING.txt)

DOCUMENTATION: http://www.msu.edu/~changs18/software.html


COMPILATION: You will need a standard C++ compiler such as GNU g++
(version 3) and additional Eigen and Boost library.

Using GTSU:

./gtsu --gtu --bfile example --setc setcol.txt --cov cov.txt --phs phe.txt --out NS




